package com.example.blinkit.models

data class Category(
    val title: String? = null,
    val image: Int
)
