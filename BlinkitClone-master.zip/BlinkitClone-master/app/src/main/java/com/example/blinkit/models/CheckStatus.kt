package com.example.blinkit.models

data class CheckStatus(
    val code:String,
    val message:String,
    val success:Boolean,
)
