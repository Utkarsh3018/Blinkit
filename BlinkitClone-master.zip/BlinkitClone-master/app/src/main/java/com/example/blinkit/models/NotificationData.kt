package com.example.blinkit.models

data class NotificationData(
    val title: String? = null,
    val body: String? = null,

    )
